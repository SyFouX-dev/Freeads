<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\annoncescontroller;
use App\Models\Annonces;

Route::get('/', [IndexController::class, 'showIndex'])->name('index');
Route::get('/create', [annoncescontroller::class, 'create'])->name('create');
Route::delete('/delete/{id}', [annoncescontroller::class, 'callDelete'])->name('delete');


Route::post('/create', function(){
    Annonces::create([
        'title'=> request('title'),
        'description'=> request('description'),
        'prix'=> request('prix'),
        'image'=> request('image')
    ]);
    return redirect('/create');
});

Route::get('/dashboard', function () {
    $posts = Annonces::all();
    return view('dashboard', [
        'posts' => $posts,
    ]);
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
