<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tringle-coin</title>
    <link rel="stylesheet" href="{{ asset('/Style/dashboard.css')}}">
</head>
<body>
    <x-app-layout>
        <a class="" href="{{ route('create') }}">Crée une annonce</a>
        <x-slot name="header">
            <h2>{{ __('TRINGLE-COIN') }}</h2>
        </x-slot>
        <P>Vous êtes bien connecté sur votre compte !</P>
        <section class="annonces">
            <h1>VOS ANNONCES</h1>
            @foreach($posts as $post)
            <div class="annonce">
                <h2>{{$post->title}}</h2>
                <p>{{$post->description}}</p>
                <img src="{{ asset($post->image)}}" alt="Votre photo">        
                <p>Prix: {{$post->prix}}€</p>
                <form action="{{ route('delete', ['id' => $post->id]) }}" method="POST">
                    @csrf
                    @method('DELETE')
                    <button type="submit">Supprimer</button>
                    <button type="submit">Modifer</button>
                </form>
            </div>
            @endforeach
        </section> 
    </x-app-layout>
</body>
</html>
