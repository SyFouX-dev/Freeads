<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil Tringle-coin</title>
    <!-- <link rel="stylesheet" href="../css/index.css"> -->
</head>
<body>
    <h1>Bienvenue sur le tringle-coin</h1>
    <button><a href="register">register</a> </button>
    <button><a href="login">login</a> </button>
</body>
</html>