<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Annonces;

class annoncescontroller extends Controller
{

    public function create(Request $request)
    {
        return view('create');
    }

    public function callDelete($id)
    {
        $this->delete($id);
    }

    public function delete($id) 
    {
        $annonce = Annonces::find($id);
        $annonce->delete();
    
        return redirect()->back()->with('success', 'Annonce a été supprimée');
    }

    public function edit($id)
    {
        $annonce = Annonces::findOrFail($id);
        return view('edit', ['annonce' => $annonce]);
    }

    public function update(Request $request, $id)
    {
        $annonce = Annonces::findOrFail($id);
        $annonce->update([
            'title' => $request->input('title'),
            'description' => $request->input('description'),
            'prix' => $request->input('prix'),
            'image' => $request->input('image')
        ]);

        return redirect('/dashboard')->with('success', 'Annonce mise à jour avec succès');
    }
}
